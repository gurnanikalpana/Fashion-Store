import React from "react";

function Footer() {
  return (
    <div className="FooterClass">
      <footer>
        <p>©2023,SiteName or its affliates</p>
        <p>
          <a href="mailto:hege@example.com">hege@example.com</a>
        </p>
      </footer>
    </div>
  );
}

export default Footer;
