const NotFound = () => {
  return (
    <>
      <div className="container">
        <div className="col-md-6 col-lg-6 text center mx-auto">
          <h1 className="text-black">404 Page not Found</h1>
        </div>
      </div>
    </>
  );
};

export default NotFound;
